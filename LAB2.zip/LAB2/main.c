#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>


#pragma pack(1)

#define OUTPUT_FILE_NAME "output.bmp"
#define INPUT_FILE_NAME "turtle_test1_v2.bin"

#define BMP_HEADER_SIZE 54
#define BMP_PIXEL_OFFSET 54
#define BMP_PLANES 1
#define BMP_BPP 24
#define BMP_HORIZONTAL_RES 500
#define BMP_VERTIVAL_RES 500
#define BMP_DIB_HEADER_SIZE 40


extern "C" int turtle(unsigned char *dest_bitma ,  unsigned char *commands, unsigned int commands_size);
  //dest_bitma is the pointer to generated image (header and pixel data)
  // commands is pointer to binary encoded turtle commands
  //commands_size- size of commands block. ( in bytes )

typedef struct
{
    unsigned char sig_0;
    unsigned char sig_1;
    uint32_t size;
    uint32_t reserved;
    uint32_t pixel_offset;
    uint32_t header_size;
    uint32_t width;
    uint32_t height;
    uint16_t planes;
    uint16_t bpp_type;
    uint32_t compression;
    uint32_t image_size;
    uint32_t vertical_res;
    uint32_t horizontal_res;
    uint32_t color_palette;
    uint32_t important_colors;

} BmpHeader;

void init_bmp_header(BmpHeader *header)
{
    header->sig_0 = 'B';
    header->sig_1 = 'M';
    header->reserved = 0;
    header->pixel_offset = BMP_PIXEL_OFFSET;
    header->header_size = BMP_DIB_HEADER_SIZE;
    header->planes = BMP_PLANES;
    header->bpp_type = BMP_BPP;
    header->compression = 0;
    header->image_size = 0;
    header->horizontal_res = BMP_HORIZONTAL_RES;
    header->vertical_res = BMP_VERTIVAL_RES;
    header->color_palette = 0;
    header->important_colors = 0;
}
/*
   write the bmp buffer array into .bmp file
*/
void write_bytes_to_bmp(unsigned char *buffer, size_t size)
{
    FILE *file;
    file = fopen(OUTPUT_FILE_NAME, "wb");
    if (file == NULL)
    {
        printf("could not open the file ");
        exit(-1);
    }

    fwrite(buffer, 1, size, file);
    fclose(file);
}
unsigned char *generate_empty_bitmap(unsigned int width, unsigned int height, size_t *output_size)
{
    unsigned int row_size = (width * 3 + 3) & ~3;
    *output_size = row_size * height + BMP_HEADER_SIZE;
    unsigned char *bitmap = (unsigned char *)malloc(*output_size);

    BmpHeader header;
    init_bmp_header(&header);
    header.size = *output_size;
    header.height = height;
    header.width = width;

    memcpy(bitmap, &header, BMP_HEADER_SIZE);
    for (int i = BMP_HEADER_SIZE; i < *output_size; ++i)
    {
        bitmap[i] = 0xff;
    }
    return bitmap;
}


int main()
{
    size_t bmp_size = 0;
    unsigned char *dest_bitma = generate_empty_bitmap(960, 160, &bmp_size);


    printf("START OF INITIAL DEBUG INFO === \n");
    printf("HEADER strcut size[bytes]: %d \n", sizeof(BmpHeader));
    printf("BMP buffer size[byte] %d \n", bmp_size);
    printf("===END OF INITIAL DEBUG INFO==\n");

    static const size_t BufferSize = 60;  //120 bytes need to read totally 60 commands, each command is 16bits. 
    int result;
    FILE *ptr;
    
    ptr = fopen(INPUT_FILE_NAME,"rb");
    unsigned char *bin_buffer = (unsigned char *) malloc(BufferSize);
    const size_t command_size = fread(bin_buffer, sizeof(unsigned char), BufferSize, ptr);
   
    printf("File size = %d bytes\n", command_size);
    printf("Size of each item in bytes = %d\n", sizeof(unsigned char));
         
    
    result=turtle(dest_bitma,bin_buffer,BufferSize);
    fclose (ptr);
    write_bytes_to_bmp(dest_bitma, bmp_size); // save the bmp buffer into file
    free(dest_bitma);
    free(bin_buffer);
    return 0;
}
  
   

 